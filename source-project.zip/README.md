# MH Bland — website concept

Independent design concept by Hamza Ghailan.

React + Vite, published from `main/docs` using GitHub Pages.

Run `pnpm install`, then `pnpm build`. Source changes require rebuilding `docs/`.

Original company branding, public company information and sourced imagery are used for concept review; see DESIGN-SOURCES.md and THIRD-PARTY-NOTICES.txt.
