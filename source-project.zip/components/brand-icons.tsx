import type { SVGProps } from "react";
type Props = SVGProps<SVGSVGElement> & { size?: number };
function Frame({size = 24, children, ...props}: Props) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>{children}</svg>;
}
export function Linkedin(props: Props) { return <Frame {...props}><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7.5 10v7M11.5 17v-7M11.5 13c0-4 5-4 5 0v4"/><circle cx="7.5" cy="7" r=".8" fill="currentColor" stroke="none"/></Frame>; }
export function Instagram(props: Props) { return <Frame {...props}><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></Frame>; }
export function Facebook(props: Props) { return <Frame {...props}><path d="M14.5 21v-8h3l.5-4h-3.5V7c0-1.2.4-2 2-2H19V1.5c-.6-.1-1.7-.2-3-.2-3 0-5 1.8-5 5.2V9H8v4h3v8"/></Frame>; }
export function Youtube(props: Props) { return <Frame {...props}><path d="M21 7.3a2.8 2.8 0 0 0-2-2C17.3 5 12 5 12 5s-5.3 0-7 .3a2.8 2.8 0 0 0-2 2A22 22 0 0 0 2.7 12a22 22 0 0 0 .3 4.7 2.8 2.8 0 0 0 2 2C6.7 19 12 19 12 19s5.3 0 7-.3a2.8 2.8 0 0 0 2-2 22 22 0 0 0 .3-4.7 22 22 0 0 0-.3-4.7Z"/><path d="m10 9 5 3-5 3Z" fill="currentColor" stroke="none"/></Frame>; }
