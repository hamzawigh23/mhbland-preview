"use client";

import { useState, type ReactNode } from "react";
import { ArrowRight, ArrowUpRight, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import people from "@/lib/people.json";

const links = [["Our story", "#our-story"], ["Marine", "#marine"], ["Tourism", "#tourism"], ["Our people", "#our-people"], ["Doing Good", "#doing-good"]];

export function Navigation() {
  const [open, setOpen] = useState(false);
  return <header className="site-header">
    <div className="header-inner container">
      <a href="#home" className="brand" aria-label="MH Bland home"><img src="/mhbland-preview/assets/logo.png" width="240" height="57" alt="MH Bland Group of Companies, established 1810" /></a>
      <nav className="desktop-nav" aria-label="Main navigation">{links.map(([label, href]) => <a key={href} href={href}>{label}</a>)}</nav>
      <a className="header-contact" href="#contact">Get in touch <ArrowUpRight size={17} /></a>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild><button className="menu-button" aria-label="Open navigation"><Menu size={27} /></button></SheetTrigger>
        <SheetContent className="mobile-navigation">
          <SheetTitle className="sr-only">Explore MH Bland</SheetTitle>
          <SheetDescription className="sr-only">Explore our services, people and community.</SheetDescription>
          <img className="mobile-logo" src="/mhbland-preview/assets/logo.png" alt="MH Bland" width="230" height="54" />
          <nav aria-label="Mobile navigation">{[...links, ["Our commitments", "#commitments"], ["Get in touch", "#contact"]].map(([label, href]) => <a key={href} href={href} onClick={() => setOpen(false)}>{label}<ArrowUpRight size={22} /></a>)}</nav>
          <p className="mobile-motto">STRENGTH IN UNITY. SINCE 1810.</p>
        </SheetContent>
      </Sheet>
    </div>
  </header>;
}

// Expanding arrow treatment adapted from cssbuttons-io on Uiverse (MIT).
export function ArrowLink({ href, children, className = "" }: { href: string; children: ReactNode; className?: string }) {
  return <a className={`arrow-link ${className}`} href={href}><span className="arrow-circle" aria-hidden="true"><ArrowRight size={20} /></span><span className="arrow-label">{children}</span></a>;
}

type Person = (typeof people)[number];
function PersonCard({ person, lead = false }: { person: Person; lead?: boolean }) {
  return <article className={`person-card ${lead ? "person-lead" : ""}`}>
    <img src={person.photo} alt={person.name} width={lead ? 108 : 72} height={lead ? 108 : 72} loading="lazy" />
    <div><h4>{person.name}</h4><p>{person.role}</p>{"location" in person && person.location ? <span className="person-location">{person.location}</span> : null}</div>
  </article>;
}

export function TeamTree() {
  const directors = people.filter(p => p.group === "Directors & Family");
  const leads = directors.filter(p => ["John A. Gaggero", "George Gaggero"].includes(p.name));
  const rest = directors.filter(p => !leads.includes(p));
  const groups = [
    { name: "Marine Division", caption: "Expertise at sea", number: "01" },
    { name: "Tourism Division", caption: "Experiences ashore", number: "02" },
    { name: "Administration", caption: "Supporting our people", number: "03" },
  ];
  return <div className="team-tree">
    <div className="leadership-node">
      <div className="node-title"><span className="red-dot" />MH BLAND GROUP<span className="node-tag">Directors & Family</span></div>
      <div className="leadership-pair">{leads.map(person => <PersonCard key={person.name} person={person} lead />)}</div>
      <Accordion type="single" collapsible className="directors-accordion"><AccordionItem value="directors"><AccordionTrigger>More directors & family <span className="count">{rest.length}</span></AccordionTrigger><AccordionContent><div className="directors-grid">{rest.map(person => <PersonCard key={person.name} person={person} />)}</div></AccordionContent></AccordionItem></Accordion>
    </div>
    <div className="tree-connector" aria-hidden="true" />
    <Accordion type="multiple" className="team-branches">
      {groups.map(group => {
        const members = people.filter(p => p.group === group.name);
        const departments = Array.from(new Set(members.map(p => p.department)));
        return <AccordionItem key={group.name} value={group.name} className="branch">
          <AccordionTrigger className="branch-trigger"><span className="branch-number">{group.number}</span><span className="branch-name"><strong>{group.name}</strong><small>{group.caption}</small></span></AccordionTrigger>
          <AccordionContent className="branch-content">
            <Accordion type="multiple" className="department-list">{departments.map(department => <AccordionItem key={department} value={department}><AccordionTrigger>{department}<span className="count">{members.filter(p => p.department === department).length}</span></AccordionTrigger><AccordionContent><div className="department-people">{members.filter(p => p.department === department).map((person, index) => <PersonCard key={`${person.name}-${index}`} person={person} />)}</div></AccordionContent></AccordionItem>)}</Accordion>
          </AccordionContent>
        </AccordionItem>;
      })}
    </Accordion>
    <p className="team-note">Explore the directors, managers and teams featured in the MH Bland directory.</p>
  </div>;
}
