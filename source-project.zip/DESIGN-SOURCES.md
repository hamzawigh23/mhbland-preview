# MH Bland — component-led redesign

Implemented 24 September 2026. Original MH Bland logo remains unchanged. Real services, company photographs and contact details are from the existing company website. This is an independent, private design concept.

## Component references and implementation

- **Bento Grid, Manu Arora**: selected on https://21st.dev/@manuarora700/components/bento-grid . Adapted the author's publicly available component structure from https://ui.aceternity.com/components/bento-grid (Manual tab). Converted the item into a semantic full-card link; customized the grid, photos, typography, overlays and hover treatment for the four tourism businesses. Licence: https://ui.aceternity.com/licence .
- **Shimmer Button, Magic UI**: adapted the public source at https://magicui.design/docs/components/shimmer-button (Manual tab), including the spark container, conic gradient, sliding and rotating animation, inset highlight and backdrop. Converted button to a semantic anchor; customized MH Bland red, restrained timing and reduced-motion behavior. See THIRD-PARTY-NOTICES.txt for MIT terms.
- **Scroll Expansion Hero, Arunachalam**: https://21st.dev/@arunachalam/components/scroll-expansion-hero . Public preview/description used as inspiration. The implementation is original React/CSS, using a passive scroll listener and requestAnimationFrame to expand the marine photograph without scroll hijacking. No locked source was retrieved.
- **Tubelight Navbar, Ayushmaan Singh**: https://21st.dev/@ayushmxxn/components/tubelight-navbar . Public preview used as inspiration. Original moving light indicator, active section observer and navigation styling; accessible mobile menu uses the installed Radix Sheet primitive. No locked source was retrieved.
- **Feature Accordion Section, Ruixen**: https://21st.dev/@ruixen.ui/components/feature-accordion-section . Pattern adapted through original layout/styling around the installed Radix Accordion primitive, with three real marine services and synchronized photographs. No locked source was retrieved.

21st.dev required sign-in to reveal some sources; no login, unlock, purchase or bypass was attempted. Sources that were publicly accessible at their authors' own websites were used directly as described above. No claim is made that all 21st.dev implementations were copied verbatim.

## MH Bland source content

https://www.mhbland.com/
https://www.mhbland.com/about-us/
https://www.mhbland.com/port-agency/
https://www.mhbland.com/marine-services/
https://www.mhbland.com/tourism-division/
https://www.mhbland.com/calypso-tours/
https://www.mhbland.com/cable-car/
https://www.mhbland.com/contact-us/

Cable Car closure for redevelopment is explicitly displayed; no ticket purchase or current operating availability is implied. Mons Calpe Suite directs visitors to enquire about availability.

## Image origins

All paths below are on www.mhbland.com. Logo bytes were preserved; photos are served as compressed WebP derivatives for loading performance.

- Logo: /wp-content/themes/mhbland/assets/images/mhbland-logo.png
- Favicon: /wp-content/uploads/2023/08/cropped-favicon-32x32.png
- Marine: /wp-content/uploads/2023/10/Lionfish-Sailing.jpg
- Cable Car panorama before footer: /wp-content/uploads/2023/10/Cable-Car-Views.jpg
- Cable Car card: /wp-content/uploads/2023/07/cable-car-1536x1024.jpg
- Calypso: /wp-content/uploads/2023/07/TOP-Calypso-Fleet-photo-with-Cruises-1024x768.jpg
- Mons Calpe: /wp-content/uploads/2023/09/Cable-Car-Photoshoot-2023-330.jpg
- Travel: /wp-content/uploads/2023/10/Queen-Mary-2-1024x488.png
- Logistics: /wp-content/uploads/2023/10/Warehouse-MHB-Port.jpg
- Diver: /wp-content/uploads/2023/10/HCR-DIVER.jpg

MH Bland retains rights to its branding and photographs. Typography uses local/system Arial and Georgia; no external font or image services are required.
